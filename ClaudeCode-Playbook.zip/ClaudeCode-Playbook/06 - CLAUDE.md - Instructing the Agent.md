# 06 - CLAUDE.md - Instructing the Agent

> *Note not yet written — video pending.*

---

## What It Is

*(to be filled)*

---

## Why It Matters

*(to be filled)*

---

## How to Use It

*(to be filled)*

---

## Best Practices

*(to be filled)*

---

## Common Mistakes

*(to be filled)*

---

## To Explore Later

*(nothing parked yet)*

---

*Related: [[MOC - Claude Code Playbook]]*
